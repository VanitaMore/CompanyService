package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.BusinessMaster;

public interface CompanyService {

	List<BusinessMaster> getAllBusinessMasterDetail();

	Optional<BusinessMaster> getMasterDetailById(String businessId);

}
