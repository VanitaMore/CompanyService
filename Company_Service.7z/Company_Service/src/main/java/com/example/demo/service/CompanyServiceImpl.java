package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.BusinessMaster;
import com.example.demo.repository.CompanyRepository;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired CompanyRepository companyRepository;
	
	@Override
	public List<BusinessMaster> getAllBusinessMasterDetail() {
		return companyRepository.findAll();
	}

	@Override
	public Optional<BusinessMaster> getMasterDetailById(String businessId) {
		return companyRepository.findById(businessId);
	}

}
