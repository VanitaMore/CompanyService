package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.SiteMaster;
import com.example.demo.repository.SiteRepository;

@Service
public class SiteServiceImpl implements SiteService {

	@Autowired SiteRepository siteRepository;
	
	@Override
	public List<SiteMaster> getAllData() {
		return siteRepository.findAll();
	}

	@Override
	public Optional<SiteMaster> getSiteMasterById(String site_id) {
		return siteRepository.findById(site_id);
	}

}
