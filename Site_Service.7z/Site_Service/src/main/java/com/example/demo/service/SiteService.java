package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.SiteMaster;

public interface SiteService {

	List<SiteMaster> getAllData();

	Optional<SiteMaster> getSiteMasterById(String site_id);

}
